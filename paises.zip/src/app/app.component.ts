import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <app-menu></app-menu>
    <router-outlet></router-outlet>
  `,
  styles: []
})

export class AppComponent {title = 'CADASTRO DE PAÍSES';}


/*import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  autenticado:string = window.localStorage.getItem('autenticado');
  title = 'CADASTRO DE PAÍSES';
}*/
