export class Pais {
  id: number;
  nome: string;
  sigla: string;
  gentilico: string;
  /*headers:{
    Content_Type :  string;
    Authorization: string;
  }*/
}
