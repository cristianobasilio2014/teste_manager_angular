export class PaisResponse {

  autenticado: boolean;
  login: string;
  administrador: boolean;
  token: string;
  nome: string;
  /*status: number;
  message: number;
  result: any;*/
}
