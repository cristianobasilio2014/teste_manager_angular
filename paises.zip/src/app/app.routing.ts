import {RouterModule, Routes} from '@angular/router';

import {LoginComponent} from "./login/login.component";
import {InserirPaisComponent} from "./Paises/Inserir/inserir-pais.component";
import {ListarPaisComponent}  from "./Paises/Listar/listar-pais.component";
import {EditarPaisComponent}  from "./Paises/Editar/editar-pais.component";
import {MenuComponent}  from "./menu/menu.component";

//import {AuthGuard} from './auth/auth.service';

const routes: Routes = [
  {path: 'login',   component: LoginComponent },
  {path: 'Inserir', component: InserirPaisComponent },
  {path: 'Listar',  component: ListarPaisComponent },
  {path: 'Editar',  component: EditarPaisComponent },
  {path: 'Menu',    component: MenuComponent },
  {path : '',       component: LoginComponent   }
];

//, canActivate: [AuthGuard] 




export const routing = RouterModule.forRoot(routes);
