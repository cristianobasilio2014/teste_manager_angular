import { Injectable, Injector } from '@angular/core';

import { map, tap, catchError } from "rxjs/operators";
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { AuthService } from '../auth/auth.service';


@Injectable()
export class RefreshInterceptor implements HttpInterceptor {

  constructor(private authService: AuthService, private injector: Injector) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

   
    return next.handle(request).pipe(
        map((event: HttpEvent<any>) => {            
            if (event instanceof HttpResponse) {
                console.log('event--->>>', event);
                debugger
                if (event.status == 401) {
                    this.authService.refreshToken();
                    //let newrequest = request.clone();
                    //return next.handle(newrequest);
                }
            }
            return event;
        }));

  }

}