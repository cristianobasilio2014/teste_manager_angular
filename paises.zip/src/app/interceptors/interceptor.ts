import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { AuthService } from './../auth/auth.service';
import { Observable } from 'rxjs';

@Injectable()

export class AuthInterceptor implements HttpInterceptor {

    constructor(private authService: AuthService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        //debugger     
        if (this.authService.isLogged()) {   
          let authToken = JSON.parse(localStorage.getItem('RetToken'));
          if (authToken.token){
            console.log('token headers',authToken.token);
               let newrequest = request.clone({
                setHeaders:
                  { Authorization: 'Bearer '+authToken.token }
                });
            return next.handle(newrequest);
          }else{
            return next.handle(request);
          }  
      }else{
        return next.handle(request);
      }
    }
}
 
