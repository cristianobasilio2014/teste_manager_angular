import { Component, OnInit } from '@angular/core';

import { Observable } from 'rxjs';
import { AuthService } from './../auth/auth.service';



@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  usuario :string; 

  isLoggedIn$: Observable<boolean>;  

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.isLoggedIn$ = this.authService.isLoggedIn; 
    let authToken = JSON.parse(localStorage.getItem('RetToken'));
    this.usuario = authToken.nome;
  }      

}
