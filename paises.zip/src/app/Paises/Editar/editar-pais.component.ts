import {Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {Pais} from "../../model/pais.model";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import {PaisService} from "../../auth/pais.service";

@Component({
  selector: 'app-editar-pais',
  templateUrl: './editar-pais.component.html',
  styleUrls: ['./editar-pais.component.css']
})
export class EditarPaisComponent implements OnInit {

  pais: Pais;
  editForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: PaisService) { }

  ngOnInit() {
    let PaisId = window.localStorage.getItem("PaisId");
    if(!PaisId) {
      alert("Ação Inválida.")
      this.router.navigate(['Listar']);
      return;
    }
    this.editForm = this.formBuilder.group({
      id: [''],
      nome: ['', Validators.required],
      sigla: ['', Validators.required],
      gentilico: ['', Validators.required],
    });
    
    this.apiService.getPaisId(+PaisId)
      .subscribe( data => {
        console.log('registro update',data);
        data = {id:202,nome:'portugal',sigla:'PR',gentilico:'Português'} //coloquei esse para teste porque não esta vindo nada do servidor
        this.editForm.setValue(data);
      });
  }

  onSubmit() {
    console.log('dados update',this.editForm.value);
    this.apiService.updatePais(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.id > 0) {
            console.log('PAIS ATUALIZADO COM ÊXITO.');
            this.router.navigate(['Listar']);
          }else {
            console.log('ERRO: AO ATUALIZAR PAIS');
          }
        },
        error => {
          console.log('erro:',error);
        });
  }

}
