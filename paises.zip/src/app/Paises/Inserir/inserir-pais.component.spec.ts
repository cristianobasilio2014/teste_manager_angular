import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InserirPaisComponent } from './inserir-pais.component';

describe('InserirPaisComponent', () => {
  let component: InserirPaisComponent;
  let fixture: ComponentFixture<InserirPaisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InserirPaisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InserirPaisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
