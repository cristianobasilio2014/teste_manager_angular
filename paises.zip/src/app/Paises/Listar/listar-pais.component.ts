import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {Pais} from "../../model/pais.model";
import {PaisService} from "../../auth/pais.service";


@Component({
  selector: 'app-listar-pais',
  templateUrl: './listar-pais.component.html',
  styleUrls: ['./listar-pais.component.css']
})
export class ListarPaisComponent implements OnInit {

  paises : any[] = [];
  
  autenticado:boolean;
  administrador:boolean;

  constructor(private router: Router, private apiService: PaisService) { }

  ngOnInit() {
    
    //debugger
    /*if(!window.localStorage.getItem('RetToken')) {
      this.router.navigate(['login']);
      return;
    }*/
    this.apiService.getPaises()
      .subscribe( data => {
        console.log('dados listar',data);
        ///debugger
          this.paises = <any>data;
      });
      let authToken = JSON.parse(localStorage.getItem('RetToken'));
      this.administrador = authToken.administrador;   
      this.autenticado = authToken.autenticado;  
  }

  deletePais(pais: Pais): void {
    this.apiService.deletePais(pais.id)
      .subscribe( data => {
        this.paises = this.paises.filter(u => u !== pais);
      })
  };

 
  editPais(pais: Pais): void {
   // window.localStorage.removeItem("PaisId");
    window.localStorage.setItem("PaisId", pais.id.toString());
    this.router.navigate(['Editar']);
  };

  insertPais(): void {
    this.router.navigate(['Inserir']);
  };
}
