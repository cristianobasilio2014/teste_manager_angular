import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import { AuthService } from './auth/auth.service';
import { AuthGuard } from './auth/auth.guard';

import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {InserirPaisComponent} from './Paises/Inserir/inserir-pais.component';
import {EditarPaisComponent} from './Paises/Editar/editar-pais.component';
import {ListarPaisComponent} from './Paises/Listar/listar-pais.component';
import {PaisService} from "./auth/pais.service";
import {HTTP_INTERCEPTORS, HttpClientModule} from "@angular/common/http";
import {ReactiveFormsModule} from "@angular/forms";
import {routing} from "./app.routing";
import {AuthInterceptor} from "./interceptors/interceptor";
import {RefreshInterceptor} from "./interceptors/refresh.interceptor";
import {DataTablesModule } from 'angular-datatables';
import {MenuComponent } from './menu/menu.component';
import { FooterComponent } from './footer/footer.component';
import {Uppercase} from './directives/uppercase.directve';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    InserirPaisComponent,
    EditarPaisComponent,
    ListarPaisComponent,
    MenuComponent,
    FooterComponent,
    Uppercase 
   
  ],
  imports: [
    DataTablesModule,
    BrowserModule,
    routing,
    ReactiveFormsModule,
    HttpClientModule    
  ],
  providers: [
    AuthService,
    AuthGuard, 
    PaisService,
   // {provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi : true},
   {provide: HTTP_INTERCEPTORS, useClass: RefreshInterceptor, multi: true },
  ],
    bootstrap: [AppComponent]
})
export class AppModule { }
