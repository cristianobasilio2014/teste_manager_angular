import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from "./../auth/auth.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  returnUrl: string;
  error: {};
  loginError: string;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService
    ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      login: ['', Validators.required],
      senha: ['', Validators.required]
    });

  }

  get login() { return this.loginForm.get('login'); }
  get senha() { return this.loginForm.get('senha'); }

  onSubmit() {
    //debugger
    this.submitted = true;
    this.authService.login(this.login.value, this.senha.value).subscribe((data) => {
      //debugger
       if (this.authService.isLogged) {        
          this.router.navigate(['Listar']);
        } else {
          this.loginError = 'Login e senha incorretos.';
        }
      },
      error => this.error = error
    );
  }
}


