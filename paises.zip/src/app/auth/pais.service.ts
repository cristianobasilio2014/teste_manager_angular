import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Pais} from "../model/pais.model";
import {Observable} from "rxjs/index";



@Injectable()
export class PaisService  {

  constructor(private http: HttpClient) { }
  baseUrl: string = 'https://mng-teste-backend.herokuapp.com';


  getPaises() : Observable<Pais> {  
    let authToken2 = JSON.parse(localStorage.getItem('RetToken'));
    console.log('token listar',authToken2.token) 
    return this.http.get<Pais>(this.baseUrl+'/pais/listar?token='+authToken2.token); 
  }
 
  getPaisId(id: number): Observable<Pais> {
    let authToken2 = JSON.parse(localStorage.getItem('RetToken'));
    console.log('token pesquisar',authToken2.token) 
    return this.http.get<Pais>(this.baseUrl+'/pais/pesquisar?filtro='+id+'&token='+authToken2.token);
  }

  insertPais(pais: Pais) : Observable<Pais> { 
    let authToken2 = JSON.parse(localStorage.getItem('RetToken'));
    console.log('token inserir',authToken2.token) 
    console.log('dados insert',JSON.stringify(pais));
    return this.http.post<Pais>(this.baseUrl+'/pais/salvar?token='+authToken2.token,pais); 
  }

  updatePais(pais: Pais): Observable<Pais> {
    let authToken2 = JSON.parse(localStorage.getItem('RetToken'));
    console.log('token update',authToken2.token)   
    console.log('dados update',JSON.stringify(pais));
    return this.http.post<Pais>(this.baseUrl+'/pais/salvar?token='+authToken2.token,pais);
  }

  deletePais(id: number): Observable<Pais> {
    let authToken2 = JSON.parse(localStorage.getItem('RetToken'));
    console.log('token delte',authToken2.token) 
    console.log('id a excluir',id);
    return this.http.get<Pais>(this.baseUrl+'/pais/excluir?id='+id+'&token='+authToken2.token);
  }
}

