import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';

//import { User } from './user';
//import { PaisService } from "../core/pais.service";

import * as jwtDecode from 'jwt-decode';
import * as moment from 'moment';




@Injectable({
  providedIn: 'root'
})

export class AuthService {
  serverUrl = 'https://mng-teste-backend.herokuapp.com';
  errorData: {};

  private loggedIn = new BehaviorSubject<boolean>(false); 

  constructor(
      private http: HttpClient
    , private router: Router
    //, private apiService: PaisService    
  ) {}
  
 

  login(username: string, password: string) {
     return this.http.post<any>(this.serverUrl+'/usuario/autenticar?login='+username+'&senha='+password,{'login':username,'senha':password})
    .pipe(map(dados => {
        if (dados && dados.token) {
          console.log('token do login',dados.token)
          localStorage.setItem('RetToken', JSON.stringify(dados));        
        }
        if(dados.autenticado === true) {
          this.loggedIn.next(true); 
        }
      }),      
      catchError(this.handleError)
    );
  }  

  refreshToken() {
    debugger
    let authToken = JSON.parse(localStorage.getItem('RetToken'));
    if (moment().isBetween(this.getExpiration().subtract(5, 'minutes'), this.getExpiration())) {
      return this.http.post(
        this.serverUrl.concat('/usuario/renovar-ticket'),{token:authToken.token}
      ).pipe(
        tap(response => this.setSession(response)),
        shareReplay(),
      ).subscribe();
    }
  }

  private setSession(authResult) {
    const token = authResult.token;
    const payload = <JWTPayload>jwtDecode(token);
    const expiresAt = moment.unix(300000);

    localStorage.setItem('RetToken', authResult);
    localStorage.setItem('expires_at', JSON.stringify(expiresAt.valueOf()));
  }


  getExpiration() {
    const expiration = localStorage.getItem('expires_at');
    const expiresAt = JSON.parse(expiration);

    return moment(expiresAt);
  }

  get isLoggedIn() {
    return this.loggedIn.asObservable(); 
  }

  isLogged() {
    if (localStorage.getItem('RetToken')) {
      return true;
    }
    return false;
  }

  getAuthorizationToken() {
    const RetToken = JSON.parse(localStorage.getItem('RetToken'));
    return RetToken.token;
  }


  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {

      console.error('ERRO:', error.error.message);
    } else {
      console.error(`RETORNO DO BACKEND STATUS: ${error.status}, ` + ` ERRO: ${error.error}`);
    }

    this.errorData = {
      errorTitle: 'REQUISIÇÃO FALHOU!',
      errorDesc: 'TENTE NOVAMENTE.'
    };
    return throwError(this.errorData);
  }
}

interface JWTPayload {
  administrador:	boolean;
  autenticado:	boolean;
  login:	string;
  nome:	string;
  token:	string;
}